/**
 * src/task_manager.ts — LongHorizonTaskManager
 *
 * 长程任务台账：纯 TypeScript + 原生 fs，零外部依赖。
 * 落盘用「临时文件 + rename」的原子写，避免进程被杀时留下半个 JSON。
 */
import { readFile, writeFile } from 'node:fs/promises';
export type LongTaskStatus = 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'EXPIRED';
/**
 * 标 COMPLETED 是否缺证据。
 *
 * 依据：ACL 2026 最佳论文《The Imperfective Paradox in Large Language Models》(689)——
 * 模型对目标导向事件系统性幻觉"已经完成"，即使文本明确说没完成。
 * 所以「完成」这个状态必须被外部证据解锁，否则只是自我感觉。
 *
 * 只要求 ≥8 个字，是为了挡住"做完了""ok"这类无信息量的答复，不是搞形式审查。
 */
export declare function completionNeedsEvidence(status: LongTaskStatus, evidence: string | undefined): boolean;
export interface LongTask {
    id: string;
    /** 任务目标。 */
    description: string;
    status: LongTaskStatus;
    createdAt: number;
    lastUpdatedAt: number;
    /** 线索：每次更新追加一条。 */
    context: string[];
    /** 任务开始时间（用户可自定义），毫秒。 */
    startAt?: number;
    /** 兼容字段：不再作为截止时间使用（任务改为提醒式）。 */
    endAt?: number;
    /** 手动排序号，小的在前。 */
    order?: number;
    /** 是否与相邻任务并行推进。 */
    parallel?: boolean;
    /**
     * 到期时间（毫秒）。到期仍未完成 → 转 EXPIRED，并下沉成一条普通记忆。
     * 依据：Hy-Memory 的 L7 INTENTION「带有效期，过期转普通事实」。
     */
    expiresAt?: number;
    /**
     * 归属主题（多对多）。空 = 未归类。
     *
     * 任务不再是独立台账，而是主题下的「进行中事项」——
     * 打开某主题就能看到它有哪些事没做完。
     */
    topicIds?: string[];
}
export interface DueTask extends LongTask {
    /** 距上次更新已经过去多久（毫秒）。 */
    overdueMs: number;
}
/**
 * 带实时逾期时长的任务视图（`/detail` 与主动扫描共用）。
 *
 * 为什么单独一个类型：`LongTask` 本身**不含** `overdueMs`，
 * 之前 `/detail` 直接把 `LongTask` 序列化出去，前端读到的 `overdueMs` 是 undefined，
 * 于是「逾期 N 小时」这类文案拿不到真实数字。
 */
export interface TaskWithAge extends LongTask {
    /** 距上次更新过去多久（毫秒）。**所有任务都有**，未逾期的也在里面。 */
    ageMs: number;
    /** 是否已经超过心跳阈值。 */
    overdue: boolean;
}
export interface TaskManagerOptions {
    /** tasks.json 的位置，默认 `~/.dsh/cognition-engine/tasks.json`。 */
    filePath?: string;
    now?: () => number;
    /** 多久没更新就算需要催办，默认 6 小时。 */
    heartbeatMs?: number;
    /** 注入点，测试可以替换成内存实现。 */
    readFileImpl?: typeof readFile;
    writeFileImpl?: typeof writeFile;
}
export declare class LongHorizonTaskManager {
    private readonly filePath;
    private readonly clock;
    private readonly heartbeatMs;
    private readonly readImpl;
    private readonly writeImpl;
    private readonly tasks;
    private seq;
    private loaded;
    private writeChain;
    constructor(options?: TaskManagerOptions);
    /** tasks.json 的绝对路径，便于告诉用户数据落在哪里。 */
    get path(): string;
    /** 启动时恢复。文件不存在视为空台账；损坏的 JSON 直接抛错，不静默吞掉。 */
    load(): Promise<this>;
    /** 创建任务并落盘。 */
    create_task(description: string, span?: {
        startAt?: number;
        endAt?: number;
        order?: number;
        parallel?: boolean;
        topicIds?: string[];
        expiresAt?: number;
    }): Promise<LongTask>;
    /** 调整排序号或并行标记（不改状态）。 */
    set_meta(id: string, meta: {
        order?: number;
        parallel?: boolean;
        topicIds?: string[];
    }): Promise<LongTask | undefined>;
    /** 更新进度：状态必填，线索可追加。 */
    update_task_progress(id: string, newStatus: LongTaskStatus, newContext?: string | readonly string[]): Promise<LongTask>;
    /** 删除任务并落盘，返回是否真的删掉了。 */
    delete_task(id: string): Promise<boolean>;
    /**
     * 到期下沉：过期的未完成任务标成 EXPIRED 并返回。
     * **不删除**——任务变成历史，同时由调用方写一条普通记忆，让这件事以"记忆"身份继续存在。
     */
    expireDue(now?: number): Promise<LongTask[]>;
    /** 未完成的任务（PENDING / IN_PROGRESS），按创建时间升序。 */
    get_pending_tasks(): LongTask[];
    /** 全部任务，按创建时间升序。 */
    all(): LongTask[];
    get(id: string): LongTask | undefined;
    /**
     * 带实时逾期的任务视图：`/detail` 用它，主动扫描也用它。
     *
     * 统一在**一个地方**算 ageMs/overdue，避免「列表页一套算法、扫描器另一套」——
     * 两套算法迟早会漂，然后就出现「页面说逾期 32 小时、提醒说逾期 29 小时」。
     */
    withAge(now?: number): TaskWithAge[];
    /**
     * 长程心跳：供外部定时器调用。
     * 返回「超过 heartbeatMs 没有更新」的未完成任务，用于催办。
     */
    check_due_tasks(now?: number): DueTask[];
    /** 手动强制落盘（一般不需要调用）。 */
    flush(): Promise<void>;
    private sorted;
    /** 串行化写入：临时文件 + rename，保证读者永远看不到半个文件。 */
    private persist;
}
